<script lang="ts">
 export let min: number = 0;
 export let max: number = 12;
 export let value: number = 8;
</script>

<div class="relative w-full ">
 <div class="relative  py-4">
  <input
   type="range"
   name=""
   id=""
   value="{value}"
   min="{min}"
   max="{max}"
   class="w-full accent-[#000000] h-[3px]"
  />

  <span
   class="absolute left-4 top-10 text-left text-base font-medium text-[#232323]"
  >
   {min}
  </span>
  <span
   class="absolute right-4 top-10 text-left text-base font-medium text-[#232323]"
  >
   {max}
  </span>
 </div>
 <div
  class="flex absolute left-0 right-0 -top-5 mx-auto w-fit flex-col items-start justify-start gap-2.5 bg-[#232323] px-3 py-1"
 >
  <span
   class="flex-shrink-0 flex-grow-0 text-left text-base font-medium text-white"
  >
   {value}
  </span>
 </div>
</div>
