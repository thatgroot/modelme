<div
  class="h-full absolute left-0 right-0 top-0 bottom-0 hidden group-hover:block bg-gradient-to-b from-[#4434c9]/80 to-[#4434c9]/0"
>
  <div class="relative overflow-hidden w-full h-full">
    <slot />
  </div>
</div>
