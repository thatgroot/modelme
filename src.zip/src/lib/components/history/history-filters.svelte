<script>
  import Checkbox from "../checkbox.svelte";
  import Dropdown from "../dropdown.svelte";
  import Input from "../input.svelte";
  import Radio from "../radio.svelte";
  import grid_svg from "../../../assets/icons/grid.svg";
  import arrow_head_down from "../../../assets/icons/arrow-head-down.svg";
  import arrow_up from "../../../assets/icons/arrow-up.svg";
  import list_svg from "../../../assets/icons/list.svg";
  import column_svg from "../../../assets/icons/column.svg";
  import RangeSlider from "../range-slider.svelte";
</script>

<div class="flex  items-center justify-between gap-4">
  <Input placeholder="Search..." />

  <div class="flex flex-grow justify-between items-center">
    <div class="flex justify-start items-center relative gap-2">
      <Checkbox label="Select all" />
    </div>
    <div class="flex justify-start items-center relative gap-4">
      <!-- "Kind", "Date Created", "Name" -->
      <Dropdown
        command="Sort by"
        before={arrow_up}
        after={arrow_head_down}
        text="Folders"
      >
        <Radio label="Kind" name="sort" value="kind" checked={true} />
        <Radio label="Date Created" name="sort" value="date" checked={false} />
        <Radio label="Name" name="sort" value="name" checked={false} />
      </Dropdown>
      <Dropdown
        command="Filter by"
        before={arrow_up}
        after={arrow_head_down}
        text="Tag"
      >
        <Radio label="Tag" name="filter" value="tag" checked={true} />
        <Radio label="License" name="filter" value="license" checked={false} />
      </Dropdown>

      <Dropdown
        command="View:"
        before={grid_svg}
        after={arrow_head_down}
        text="Grid"
      >
        <Radio label="Grid" icon={grid_svg} />
        <Radio label="List" icon={list_svg} />
        <Radio label="Column" icon={column_svg} />
        <RangeSlider min={0} max={12} value={8} />
      </Dropdown>
    </div>
  </div>
</div>
