<script lang="ts">
  export let lable: string;
</script>

<div
  class="flex relative justify-start px-2 items-center w-[163px] h-[42px]"
>
  <span class="text-lg font-bold text-left text-white z-[999] py-5">{lable}</span>

  <svg
    width="163"
    height="42"
    viewBox="0 0 163 42"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    preserveAspectRatio="none"
    class="absolute right-0 bottom-0 left-0 top-0"
  >
    <path d="M0 0.14917H139L124.944 41.1492H0V0.14917Z" fill="#1F206C" />
    <path d="M0 0.14917H139L124.944 41.1492H0V0.14917Z" fill="#1F206C" />
    <path d="M145 0.14917H151L133 41.1492H127L145 0.14917Z" fill="#1F206C" />
    <path d="M157 0.14917H163L145 41.1492H139L157 0.14917Z" fill="#1F206C" />
  </svg>
</div>
