<script lang="ts">
  //
</script>

<div
  class="max-w-full  flex flex-col justify-center items-start  overflow-hidden gap-3 py-3 bg-[#fffefe]"
>
  <svg
    height="4"
    viewBox="0 0 1440 4"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    preserveAspectRatio="xMidYMid meet"
  >
    <line y1="1.64941" x2="1440" y2="1.64941" stroke="black" stroke-width="3" />
  </svg>
  <div class="flex justify-start items-center relative gap-12">
    <svg
      width="24"
      height="25"
      viewBox="0 0 24 25"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      class=" w-6 h-6 relative"
      preserveAspectRatio="none"
    >
      <path
        d="M12 2.89941V21.3994"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M21.25 12.1494L2.75 12.1494"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M18.541 5.60889L5.45954 18.6904"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M18.541 18.6899L5.45954 5.60846"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
    </svg>
    <p class=" text-[40px] text-left text-black">MODELME</p>
    <svg
      width="24"
      height="25"
      viewBox="0 0 24 25"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      class=" w-6 h-6 relative"
      preserveAspectRatio="none"
    >
      <path
        d="M12 2.89941V21.3994"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M21.25 12.1494L2.75 12.1494"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M18.541 5.60889L5.45954 18.6904"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M18.541 18.6899L5.45954 5.60846"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
    </svg>
    <span class=" text-lg font-semibold text-left min-w-fit text-black"> #1 Upload </span>
    <svg
      width="24"
      height="25"
      viewBox="0 0 24 25"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      class=" w-6 h-6 relative"
      preserveAspectRatio="none"
    >
      <path
        d="M12 2.89941V21.3994"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M21.25 12.1494L2.75 12.1494"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M18.541 5.60889L5.45954 18.6904"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M18.541 18.6899L5.45954 5.60846"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
    </svg>
    <span class="min-w-max text-lg font-semibold text-left text-black">#2 Select</span>
    <svg
      width="24"
      height="25"
      viewBox="0 0 24 25"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      class=" w-6 h-6 relative"
      preserveAspectRatio="none"
    >
      <path
        d="M12 2.89941V21.3994"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M21.25 12.1494L2.75 12.1494"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M18.541 5.60889L5.45954 18.6904"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M18.541 18.6899L5.45954 5.60846"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
    </svg>
    <span class="min-w-max text-lg font-semibold text-left text-black">#3 Generate</span>
    <svg
      width="24"
      height="25"
      viewBox="0 0 24 25"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      class=" w-6 h-6 relative"
      preserveAspectRatio="none"
    >
      <path
        d="M12 2.89941V21.3994"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M21.25 12.1494L2.75 12.1494"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M18.541 5.60889L5.45954 18.6904"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M18.541 18.6899L5.45954 5.60846"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
    </svg>
    <p class=" text-[40px] text-left text-black">MODELME</p>
    <svg
      width="24"
      height="25"
      viewBox="0 0 24 25"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      class=" w-6 h-6 relative"
      preserveAspectRatio="none"
    >
      <path
        d="M12 2.89941V21.3994"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M21.25 12.1494L2.75 12.1494"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M18.541 5.60889L5.45954 18.6904"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M18.541 18.6899L5.45954 5.60846"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
    </svg>
    <span class="min-w-max text-lg font-semibold text-left text-black">#1 Upload</span>
    <svg
      width="24"
      height="25"
      viewBox="0 0 24 25"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      class=" w-6 h-6 relative"
      preserveAspectRatio="none"
    >
      <path
        d="M12 2.89941V21.3994"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M21.25 12.1494L2.75 12.1494"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M18.541 5.60889L5.45954 18.6904"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
      <path
        d="M18.541 18.6899L5.45954 5.60846"
        stroke="black"
        stroke-width="1.5"
        stroke-linecap="square"
      />
    </svg>
    <span class="min-w-max text-lg font-semibold text-left text-black">#2 Select</span>
  </div>
  <svg
    height="4"
    viewBox="0 0 1440 4"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    preserveAspectRatio="xMidYMid meet"
  >
    <line y1="1.64941" x2="1440" y2="1.64941" stroke="black" stroke-width="3" />
  </svg>
</div>
