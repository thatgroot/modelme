<script lang="ts">
  import image_19 from "../../../assets/19.png";
  import image_21 from "../../../assets/21.png";
  import image_22 from "../../../assets/22.png";
  import image_23 from "../../../assets/23.png";
  import image_24 from "../../../assets/24.png";
  import image_25 from "../../../assets/25.png";
  import image_26 from "../../../assets/26.png";
  import image_27 from "../../../assets/27.png";
  import image_28 from "../../../assets/28.png";
  import image_29 from "../../../assets/29.png";
  import image_30 from "../../../assets/30.png";
  import image_31 from "../../../assets/31.png";
  import Badge from "../badge.svelte";
  import CardOverlay from "../card-overlay.svelte";
</script>

<div
  id="howto"
  class="flex flex-col justify-start items-center overflow-hidden gap-[54px] px-[83px] py-[41px] bg-white border-t-0 border-r-0 border-b border-l-0 border-[#232323]/[0.16]"
>
  <div class="flex flex-col justify-start items-center gap-[61px]">
    <div class="flex justify-start items-start relative gap-[460px]">
      <div class="flex flex-col justify-start items-start relative gap-[18px]">
        <span class="text-lg font-semibold text-left text-[#1f206c]"
          >HOW TO</span
        >
        <p class="text-[58px] text-left text-neutral-900 leading-[4rem]">GENERATE!</p>
      </div>
      <span class="w-[570px] text-lg text-left text-[#757575]">
        Your products, your generated models. Apply the same generated model to
        all your product and company imagery.
      </span>
    </div>
    <div class="flex flex-col justify-start items-start relative gap-2.5 p-2.5">
      <svg
        width="829"
        height="504"
        viewBox="0 0 829 504"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        xmlns:xlink="http://www.w3.org/1999/xlink"
        class="flex-grow-0 flex-shrink-0"
        preserveAspectRatio="none"
      >
        <path
          d="M0.5 0.149414H828.5V503.149H0.5V0.149414Z"
          fill="url(#pattern0)"
        />
        <defs>
          <pattern
            id="pattern0"
            patternContentUnits="objectBoundingBox"
            width="1"
            height="1"
          >
            <use
              xlink:href="#image0_160_6460"
              transform="matrix(0.001808 0 0 0.00297619 -0.0333599 0)"
            />
          </pattern>
          <image
            id="image0_160_6460"
            width="590"
            height="336"
            xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAk4AAAFQCAYAAABJbfGDAAAEDmlDQ1BrQ0dDb2xvclNwYWNlR2VuZXJpY1JHQgAAOI2NVV1oHFUUPpu5syskzoPUpqaSDv41lLRsUtGE2uj+ZbNt3CyTbLRBkMns3Z1pJjPj/KRpKT4UQRDBqOCT4P9bwSchaqvtiy2itFCiBIMo+ND6R6HSFwnruTOzu5O4a73L3PnmnO9+595z7t4LkLgsW5beJQIsGq4t5dPis8fmxMQ6dMF90A190C0rjpUqlSYBG+PCv9rt7yDG3tf2t/f/Z+uuUEcBiN2F2Kw4yiLiZQD+FcWyXYAEQfvICddi+AnEO2ycIOISw7UAVxieD/Cyz5mRMohfRSwoqoz+xNuIB+cj9loEB3Pw2448NaitKSLLRck2q5pOI9O9g/t/tkXda8Tbg0+PszB9FN8DuPaXKnKW4YcQn1Xk3HSIry5ps8UQ/2W5aQnxIwBdu7yFcgrxPsRjVXu8HOh0qao30cArp9SZZxDfg3h1wTzKxu5E/LUxX5wKdX5SnAzmDx4A4OIqLbB69yMesE1pKojLjVdoNsfyiPi45hZmAn3uLWdpOtfQOaVmikEs7ovj8hFWpz7EV6mel0L9Xy23FMYlPYZenAx0yDB1/PX6dledmQjikjkXCxqMJS9WtfFCyH9XtSekEF+2dH+P4tzITduTygGfv58a5VCTH5PtXD7EFZiNyUDBhHnsFTBgE0SQIA9pfFtgo6cKGuhooeilaKH41eDs38Ip+f4At1Rq/sjr6NEwQqb/I/DQqsLvaFUjvAx+eWirddAJZnAj1DFJL0mSg/gcIpPkMBkhoyCSJ8lTZIxk0TpKDjXHliJzZPO50dR5ASNSnzeLvIvod0HG/mdkmOC0z8VKnzcQ2M/Yz2vKldduXjp9bleLu0ZWn7vWc+l0JGcaai10yNrUnXLP/8Jf59ewX+c3Wgz+B34Df+vbVrc16zTMVgp9um9bxEfzPU5kPqUtVWxhs6OiWTVW+gIfywB9uXi7CGcGW/zk98k/kmvJ95IfJn/j3uQ+4c5zn3Kfcd+AyF3gLnJfcl9xH3OfR2rUee80a+6vo7EK5mmXUdyfQlrYLTwoZIU9wsPCZEtP6BWGhAlhL3p2N6sTjRdduwbHsG9kq32sgBepc+xurLPW4T9URpYGJ3ym4+8zA05u44QjST8ZIoVtu3qE7fWmdn5LPdqvgcZz8Ww8BWJ8X3w0PhQ/wnCDGd+LvlHs8dRy6bLLDuKMaZ20tZrqisPJ5ONiCq8yKhYM5cCgKOu66Lsc0aYOtZdo5QCwezI4wm9J/v0X23mlZXOfBjj8Jzv3WrY5D+CsA9D7aMs2gGfjve8ArD6mePZSeCfEYt8CONWDw8FXTxrPqx/r9Vt4biXeANh8vV7/+/16ffMD1N8AuKD/A/8leAvFY9bLAAAAimVYSWZNTQAqAAAACAAEARoABQAAAAEAAAA+ARsABQAAAAEAAABGASgAAwAAAAEAAgAAh2kABAAAAAEAAABOAAAAAAAAAJAAAAABAAAAkAAAAAEAA5KGAAcAAAASAAAAeKACAAQAAAABAAACTqADAAQAAAABAAABUAAAAABBU0NJSQAAAFNjcmVlbnNob3RLaUGZAAAACXBIWXMAABYlAAAWJQFJUiTwAAAB1mlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iWE1QIENvcmUgNi4wLjAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczpleGlmPSJodHRwOi8vbnMuYWRvYmUuY29tL2V4aWYvMS4wLyI+CiAgICAgICAgIDxleGlmOlBpeGVsWURpbWVuc2lvbj4zMzY8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+NTkwPC9leGlmOlBpeGVsWERpbWVuc2lvbj4KICAgICAgICAgPGV4aWY6VXNlckNvbW1lbnQ+U2NyZWVuc2hvdDwvZXhpZjpVc2VyQ29tbWVudD4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+CjXvw7MAAAAcaURPVAAAAAIAAAAAAAAAqAAAACgAAACoAAAAqAAAHjpEVBNXAAAeBklEQVR4Aezd2VYbybaF4QD1LWDcVO2q8/6X53pfnZepzi5aob6BM2eIwEKWIQCBJfnXKEoCJ1LmlzkGc6yIWLn3v//9v5vAAwEEEEAAAQQQQOBRgT2C06NGbIAAAggggAACCEQBghMXAgIIIIAAAgggkClAcMqEYjMEEEAAAQQQQIDgxDWAAAIIIIAAAghkChCcMqHYDAEEEEAAAQQQIDhxDSCAAAIIIIAAApkCBKdMKDZDAAEEEEAAAQQITlwDCCCAAAIIIIBApgDBKROKzRBAAAEEEEAAAYIT1wACCCCAAAIIIJApQHDKhGIzBBBAAAEEEECA4MQ1gAACCCCAAAIIZAoQnDKh2AwBBBBAAAEEECA4cQ0ggAACCCCAAAKZAgSnTCg2QwABBBBAAAEECE5cAwgggAACCCCAQKYAwSkTis0QQAABBBBAAAGCE9cAAggggAACCCCQKUBwyoRiMwQQQAABBBBAgODENYAAAggggAACCGQKEJwyodgMAQQQQAABBBAgOHENIIAAAggggAACmQIEp0woNkMAAQQQQAABBAhOXAMIIIAAAggggECmAMEpE4rNEEAAAQQQQAABghPXAAIIIIAAAgggkClAcMqEYjMEEEAAAQQQQIDgxDWAAAIIIIAAAghkChCcMqHYDAEEEEAAAQQQIDhxDSCAAAIIIIAAApkCBKdMKDZDAAEEEEAAAQQITlwDCCCAAAIIIIBApgDBKROKzRBAAAEEEEAAAYIT1wACCCCAAAIIIJApQHDKhGIzBBBAAAEEEECA4MQ1gAACCCCAAAIIZAoQnDKh2AwBBBBAAAEEECA4cQ0ggAACCCCAAAKZAgSnTCg2QwABBBBAAAEECE5cAwgggAACCCCAQKYAwSkTis0QQAABBBBAAAGCE9cAAggggAACCCCQKUBwyoRiMwQQQAABBBBAgODENYAAAggggAACCGQKEJwyodgMAQQQQAABBBAgOHENIIAAAggggAACmQIEp0woNkMAAQQQQAABBAhOXAMIIIAAAggggECmAMEpE4rNEEAAAQQQQAABghPXAAIIIIAAAgggkClAcMqEYjMEEEAAAQQQQIDgxDWAAAIIIIAAAghkChCcMqHYDAEEEEAAAQQQIDhxDSCAAAIIIIAAApkCBKdMKDZDAAEEEEAAAQQITlwDCCCAAAIIIIBApgDBKROKzRBAAAEEEEAAAYIT1wACCCCAAAIIIJApQHDKhGIzBBBAAAEEEECA4MQ1gAACCCCAAAIIZAoQnDKh2AwBBBBAAAEEECA4cQ0ggAACCCCAAAKZAgSnTCg2QwABBBBAAAEECE5cAwgggAACCCCAQKYAwSkTis0QQAABBBBAAAGCE9cAAggggAACCCCQKUBwyoRiMwQQQAABBBBAgODENYAAAggggAACCGQKEJwyodgMAQQQQAABBBAgOHENIIAAAggggAACmQIEp0woNkMAAQQQQAABBAhOXAMIIIAAAggggECmAMEpE4rNEEAAAQQQQAABghPXAAIIIIAAAgggkClAcMqEYjMEEEAAAQQQQIDgxDWAAAIIIIAAAghkChCcMqHYDAEEEEAAAQQQIDhxDSCAAAIIIIAAApkCBKdMKDZDAAEEEEAAAQQITlwDCCCAAAIIIIBApgDBKROKzRBAAAEEEEAAAYIT1wACCCCAAAIIIJApQHDKhGIzBBBAAAEEEECA4MQ1gAACCCCAAAIIZAoQnDKh2AwBBBBAAAEEECA4cQ0ggAACCCCAAAKZAgSnTCg2QwABBBBAAAEECE5cAwgggAACCCCAQKYAwSkTis0QQAABBBBAAAGCE9cAAggggAACCCCQKUBwyoRiMwQQQAABBBBAgODENYAAAggggAACCGQKEJwyodgMAQQQQAABBBAgOHENIIAAAggggAACmQIEp0woNkMAAQQQQAABBAhOXAMIIIAAAggggECmAMEpE4rNEEAAAQQQQAABghPXAAIIIIAAAgggkClAcMqEYjMEEEAAAQQQQIDgxDWAAAIIIIAAAghkChCcMqHYDAEEEEAAAQQQIDhxDSCAAAIIIIAAApkCBKdMKDZDAAEEEEAAAQQITlwDCCCAAAIIIIBApgDBKROKzRBAAAEEEEAAAYIT1wACCCCAAAIIIJApQHDKhGIzBBBAAAEEEECA4MQ1gAACCCCAAAIIZAoQnDKh2AwBBBBAAAEEECA4cQ0ggAACCCCAAAKZAgSnTCg2QwABBBBAAAEECE5cAwgggAACCCCAQKYAwSkTis0QQAABBBBAAAGCE9cAAgi8mcDNzU24vv20fT3v7e3F7/zsl37eD/OfLe/UdbgJ/n39F5/97997v+Xf5XsEEEBgXQIEp3VJ8j4IIPCggEPOTKnJz344JBWUnvb3HZoUmPb3Q3GvEPadoFY8rvV705tZuL5WhNLr6+vV7+f34oEAAgi8lgDB6bVkeV8EfmKBu3CkUFTYUyDaLygk7Yd9JaU9fb9f1Je+LzgwOT2pylTQtvv+N3+74qG8FK5vrhW+HLwUnJTCZjFAXYfrqcOUnv0zbTi9nunf9LO47dfK1oq35UcIIIDAkwQITk/iYmMEEHhMIFWWlIEUmPZDuVQIlVI1VKrlUC2X9bocypViKBUVphSY9gqLFaLF16s+aV6t8r/czFRxUoCaTGdhPJqG0WQchuNxGA31NRmG8WSmAOXwFGJli0rUKk9+hgACTxUgOD1VjO0RQOBO4K6ydDvUVi4UQ1GBaM/VpEIhlErzgFQulRSU9G/+mf69pOc9f/n3HstKd592/4WLSf78m9ksTPylADWNz1OFpkn8fjKZhpl+duMqlAPWbHo31Od3I0zdN+U7BBB4XIDg9LgRWyCAwAqBVFnyP3m0zZWker0a6lV/VVRVUmXJVSX/Y5p3dFsw8nDdOh8epouPFMIUqGYathvHatQ49IcjfQ1Dvz+MlSnPtfJjvmvpl+Y/4/8IIIDAQwIEp4d0+DcEELgnsFxhKu2roqShuKIqSlUFpfil4biyK023VSXPXfIjVYjuveGav1msYHkuVKpGjVV58jDecDT/mroipaG8yTUVqDWfAt4OgZ0XIDjt/CnmABFYj8ByhalaqoRmsxGajVqsMFXKpVhdcjXJTQc0CLeeD37hu6R9cVXKVajReBIrUN3eIHS7vTCcjOJqP38MFagXYvPrCPwEAgSnn+Akc4gIvFTAocnVHA+7VQqar6SJ3vVKJQ7NVSua+K0huf3bOUv+rFSZWv7c+3OKUk+muFxOv6OqVOrVFH/xdjzttrNTrCZ5MrkLWKpiOaDNRwC/DrU99rn+92vNeRppCG84mg/d9UejMPGE8tkkBqt0rMv7zvcIIICABQhOXAcIIPCggIOE5wSV1EKgWauGRqMR2q2mglP5rsL04Bvc/qNDjns07d0O3blVQBpOc+uAmVbJeXJ3/JlTlELU/OGQNG9X4MnlBa3Cc4sDTy73MODi+7nXU/zV29986ClVoPoavutcdUOv1wvdwVCTyq+pPD0Ex78h8JMLEJx+8guAw0fgMQFXmcqa+F1TUGpo8netpqE5VZuKWiWXKkjLlZ7Fn6eA4saVbg/gPkt+Hb9XSEmv47NbDDj5OADd7lisJzk46Wtfocn9n9JX8bYfVOwJpZ+7/UF8rX2eV6Tm1aiH9m86nQZXnQaDQehp8vhAQWqs1gYe1uOBAAIILAsQnJZF+B4BBO4J1MuVcHh0ENqNuiZ/ax6T2w08MH9J+SZWlvwmrgDNNAnb7QEGI88tGoSBJmnPPDlb1SVXmNwB3I8YlW7TUvpJ/AcPz81fqEbu/+bfueN4bG/gypMmp9c0Kb1erSnglRT0tJ+atJ66kD9WifI8qFkcvpuETq8fLs4vQ388Sp/KMwIIIHAnQHC6o+AFAgik+T2u2rgnU1ltBRoanjvQJHCvmEtVplUVHP8sVZdiZUmVnLG+vHrNwWmsSdnuqzRxaFJn7+v4NR8GfI68J3I7PO2rK3nJX+4VpdV8ZU1Sj32jFJzKqooV3D9Kx+PKWapCfW//XX3yyrtLTRrvadhurDYGi72fUiXtOfvL7yCAwG4IEJx24zxyFAi8WMBhwqNTHg6rFktxtdy7o0MFJw3Lue+S5xP5eemRKkzz6tJUFaVJDB19DX0NHTwUlnwLlOWwkr5/7oBY2pPlMOPvfYsXt0SoKvjVNbTo8Ffzqj/9zFWo71WgHPzcN2Gq595gFM7OL4JX3w2nE00qv2Hu09K551sEfkYBgtPPeNY5ZgSWBBxibhQoPNnajSyb9Vpoqcrk4TlXch56xF5J6oc0Hs80HKe5QqrYjDQcN1WAGmqu0ERpLIUkh5oUeB56z+f8mwPY4ueUVGGq6liKCkwVDePF272oaua2CWUN73kV4EMPV8Y8bHel6lO3P7htnKnVhbJaDmsPvQ//hgACuyVAcNqt88nRIPBkAYcNV5qKRVWaFDBazWZ4f9hWpaYSO34/FHVcofHwWwoYcXhLgWP+8NCdv568S2v5BWW024AznxNV0tBjVcfkvlPvWm0N6Xly+/djnOc9eef7qjydXHQUoLqxieZ0SuVpLSeIN0FgSwUITlt64thtBNYhEIPNbaVpHppUZWrWQ7tWjxOuUwUnfZYrLf7ZteYCjZS2XFkaaC7QQLczGSpgDFRh8vym16wspX3JfU6VKK/Kq2gIsuLwpIpavVJTUNT8Jw3fFbw6b68Qj23xfX0cnsjeGfRDpzuvPrkDuVsmUHlalOI1Aj+PAMHp5znXHCkC9wQcgFZXmqorKzHKEHF+kFfCDcdTzf3ph/POlQLTUIFDq9L0lVbI3fugDfomBjoNRxYUkqpqqXDYaoVmyyvxNKSnobuH5j71dZxUnjboZLIrCPwgAYLTD4LnYxHYCAGFoWpRw3PtZjhoPVxp8iq4qSZJD0ZT9TtSzyMFib6ex/rZNj7Kqj7V3NBTX03N5apVVH3Sz7xKb1WlLVWeLq9Ueepo2G46dg8FHggg8JMJEJx+shPO4SKQBGIfJN2k16Hh4/GRmltWVGn6dsJ0qjT5Hm9ept/xUn0NW40UmJYDRnrvbXl2BcrDd/Nu6PXYdsGTx79feZopNI7Cl9PzWHGbxpsEk5625XyznwisQ4DgtA5F3gOBLRNwYHDFpa6J0u7RdNhqaPVc+Zsg5O08n2mo5pC9fj8GJ89piqvmNmwu01NPQZr75B5PXnXn6pMtGnU1+vS999T/aTkY2mOieVwXV71o0VerAlfclrd76r6wPQIIbI8AwWl7zhV7isBaBPS3P07ebmgC+Mf3R6GloJCaQy5+gLdzz6OBboZ7cq5VZRqi6uu1O3778f31aIvvsvmvHaD8KGmOU103LG5pyPL9UVtDd9WVlafU5PNKQfLLybmGLPsxOP2o1YPzvef/CCDwVgIEp7eS5nMQ2AABV0aKqqZ4RVlLq+eODw9CRROjlx+x0qRhqJG6fruP0dnFlW6X0o+hyQHB/75LwckuDooxPFXr4d1hK/axqvi2LRrOXFVRGqlf1enFpXwcKAea/zWLLsuWfI8AArslQHDarfPJ0SDwXQH/8fcquoZWk70/PgwHmhDuDuH7ClKLj1WVpp6CwUTBwGHJoWkXH/Zx9akkj4aD5SOVp2vf207DdJeaKH5yehF6av7p28Dsqs8unnOOCYHnCBCcnqPG7yCwZQIOBb7/XEFNIN0A8uM7DdFpTo/G4vSH/mvtyJnoWnOXJgoEHa2YOzvthF6qNGmETm+xs8EgBiclJ8+Pd+Wp4crTcTu01fOpFFfb7avy9PXEp9uzXGnO1+fTszhZfKZhTL8P4emrE68Q2DUBgtOunVGOB4ElAf8hd6WpUi6EVsNtB5rhsN3QvdzuTwZPlSY3eHR/pktNgHavJt+o19HKt2T5GrGWPmRHvnXFyY0t/ewbBHvF4YEmzh+1W7Gr+vJqOwek0XgYzi+vwkWnH+c7jTW8SeVpRy4IDgOBFQIEpxUo/AiBXRNweKpVq+FYlaZDDUG5S7gbProDth8OTdpE1aZpuNJy+9MzL7efrxib6ea2L600+fPnn7P5w3zeVxXdVJ2brzx0hc5uLbVr8HynZOXj8b39prrlTF/DdF5pd3Z+qeagIypO8WzzPwR2U4DgtJvnlaNC4J6AKyPNeiP89um9ehapM/hC7chBwKvnHAB6w1FcZn+uANCfjG7fY3Hre2+b9U0KIt74pQEs6wPXsJErTqm7Zb1UCUdHB/NWBdVKvEXLcuXJw3ZXGtr8+/OJbgg8X2W3ht3gLRBAYAMFCE4beFLYJQTWJeDQUlBlqeab92qI7v27Q83dqXyzzD4NOZ2eX4WOKie9oSaDa8jpOUHH7+XmmiVVZ0r6XL/2rVhu1HncE8zdNHKmsUPvm7fd1EcKfCWtrGtUa6GtIbvjo5aGPKtx39N+p+Dp0HlydqG2Dd0w8P3sNN9pk48v7T/PCCDwNAGC09O82BqBrRFIf/jdbuDooB3n6jQ1IbyouTurHp7P9GesmPRiMHDV5TlzmgpKW+7GXdMQ16FW7tU0l+pa+WigYNFRqPCtWjycNZu+fAhw1XGs82fJwAEoVew872nVY6q5YF0dm+eGnV92gtsVPCd4rnpvfoYAApsjQHDanHPBniCwdgGHp4YaOX74cKzgpNVhnqOjClR6uFriZfWDye2yelVM+go4z/2D78+rKCi5R1RbFa62QkapVFIQm6/Uu+oNVc1ScBqOw1TBYjKbqgLlGwSr+rShFagUQOuq1Lli5zYONR2T2zhol+8eN6owTVRN61wN4io7H+dzgufdG/ICAQQ2UoDgtJGnhZ1CYD0CrpS0NLfp11/exw7hi++ahpjcGTwN0aXO4M/5g58CRqNeDb98eK+gVo8T0FO7A4enGw3ZeahuPFZjTVW40rCgh7U8Ifu5gW3xuF7jtStPqbN4GrL7Xmdx3wD5r39PdXyq3Omg7MIDAQR2R4DgtDvnkiNB4E7Af6w9t8kNLpuqkMSb+K6Y2+SF992++hD9exZ6+kPv6s9z/9D799z2oKUhuv/59VNo675vi48U1Dyxeqb5U54H5F5RDhpTvR5rcnq6aW7ah02aI+R98X3tfEPgTx/eaehu9ST7+VwndRTXkN1ArQqY67R4FfAage0XIDht/znkCBC4J+DQ4epNpVJU64GWVoO1QrNZjU0cFzd0BWiqSs+l7kH3+eQ09AeDF01mfiw4LX+2ZqjHITrfJLevFghuf+Dbuwy1ms/778emVaB8jPVaLXx676HP+xW1+R6H2Dy0qzB4qb5OF1eXmuukPlgq4W1SCEz7yjMCCDxdgOD0dDN+A4GNFkgBxrdW+ajKiOcaVTQfZ39pbtMktR/QhO2Li45u5vuyyczpc79XcVpGSxUoh7fx2BOrB6p+DcJwMFL1aRKrT5u0+s7H50BX02T7w0NPtm/GFYqlku9l9/XornU8I80b80T4L67kcSuWrzi8QmAHBAhOO3ASOQQEFgVSgPFQ0u+fPsT+Q4u3VkmBxXObTs46cfl8X6vcJhpne87cpvTZ6XNzg1P6PT97YvVMFTA32/QQXk/zn1yBird7mWi/NqRi40JYSW3B6+XKbXuHtoJU9V57B1fyXE27VPXsj8//xqFQOokvnm1eI7DdAgSn7T5/7D0CKwU8LOTl87//8iHem26xIpJ+wXOL/tYQXVdzm1JlJ/3bc55fEpwWP8/L+oeq0vRUgbrS/KuJV9+pgjNTH6jZ7RysHzns5c8uKAk1NdfpVw3ZNXQvu+WHw6mD3x//ODjN2zssb8P3CCCwnQIEp+08b+w1At8V8M18y1ou39Lk7E/v333T8DKublN16VIdrv9x36YXzm1KO7Ku4OQJ6x77cpgbKzD13RtJ1ZuB9tP30duE/k8+1qbmOv2iTuwH9bpaPOxrDtO8Xpcqep4k/vnkLM7b8tCjb57MAwEEtl+A4LT955AjQOBOwH/QfXPamqogntt0fPDtzWndt8l/yC81B+fz6bnuszZey01p1xWcUvDQaFdc4TfWZPErVW/cXDLOfxp7/pPbF/yY/k/pOOua6/Tp+CjOdXJQdV8nP9L+O+Sd6ua/nus0UHXPN0v+kZWyu4uEFwgg8CIBgtOL+PhlBDZHwH/QXdTwarqjA91brdHUcNK3ncInWsU2X/XVDeedqzDSxOx1zMFJgeI5c5weUkwVspEqUKM4/8mr7/oKfIO41N/H/JZzoNJxVspybmvVoto9NBVUS2r9sPiIncTV8POyJ+dLVtct2vAagW0WIDht89lj3xFYEEh/0OtaTfdBq+mO1LV7sRLiTV0N8a1ATrWKrqPw0Rv0n31PuoWPji/T5687OKUKzszNM1W1cYWs2/XE8Xn/J69gm6kDuT/fX368ZmXHn+GwFu9hV1OHdHVJP9YqO9/a5vbj4z6kyt65Jrr/q9V1fVbXRRf+h8C2CxCctv0Msv8I3Aqk4OLVdL99/KjVdLXvzr35x3NvOj2tpNOtTxRIXrKaLp2A9PnrDk7p/f08rz5p/pPmQbmFQV+3NemqqtN94/5Pnq1U9I2MC7q9TLsRfnloLplC3p9fvrC6bvFE8hqBLRYgOG3xyWPXEVgUSJWQtjp3//Yfde7Wqq/FR6rcXGm+zZ9aJu9mk/4df63j8RbByfuZjsP9n4YKT54/1NHKwKEmY7s31eR2/pP35zUrT35vf3kS/m9q+9DScJ27oi9zet/+/Ouz9nHwpkOK6zinvAcCCHwrQHD61oSfILC1Ag4Lbc1t+v3Xj3EIadUf8q6Gjv74+7OW+vfDjf7wr6PaZLC3Ck6LJ8f9n3ybGE8WH2oIr+feT2ph8Bb9n1x18o2JW1pV97tuMdPU0OjiIwU8D4n+8fcXBafuqwa5xc/mNQIIvJ4Awen1bHlnBN5UwH+oYwUkBif1b9Jy+cXgFCshChluQ/CXKyBapbaOSeHpIH9EcEqf7ec4/0lVJ/encouFydDDkPNQ5RV4665ApeNt16rhP6rwuS2BS0o+D36k4OR9+eNvVfgUnPw78TzMN+H/CCCwhQIEpy08aewyAqsE9jXnprhf1NBRM/z6SY0Zl27qe6NVaa7MuCdS7N+kkLFLwSl17J6qc7eX/vv+d1fdrp7VxmC6/v5PKTg15Rz7OWnIrrhfiPPKfH5ScHI/p78/n8Z9STcxXnX++BkCCGyHAMFpO84Te4nAowIFVTsqWhLfjJOVj765Fchr30MtBYnXnBz+EEIKKov9nzpefXfb/2mk/k+zm6lWxM3ndXl/XzIHKh3v9+4JmPbHt7b5cnIR55QNJwpwCrA8EEBgewUITtt77thzBO4J+DYg1ZJWebUa4ePx4bfBSVWYgcKDG1+enF2srfFl2okUJH5UcPJ+OKykoTBXoBxSJmpVEOc/qfLk1XduCzDT3CiN3r1osnY6XjfCfP/uMDbCrJXdCLMYSVJwciPMk7NLtX9Q93OFqKnaJ/BAAIHtFSA4be+5Y88RuCdQKhRCVX/EW+oY/uFdO1TL928+m+YAda564eTiMoaJXRqqu4ehb1Jwmfd/mqh1wUTzjHqxAjVWmHEj0FR9Wv7dnO9TcKqq4ehx+zC01QizUauE4lJwctPOs8uuhkjdQXyoYcRJztuzDQIIbKgAwWlDTwy7hcBTBYq65Ue9UlMn63p4d3ig4FS+NzncQaE3GKni1FMn6wsFp/V0DE/7mYLEj6w4pX1Jz6kClbqPT2/mLQy8+s6Ttl8SZNLxVsqFcNhSB3HNLWupGWZJt1/xIwU3DxFedLqqOHXjjX8JTuns8IzAdgoQnLbzvLHXCHwjUNb8ppqaX/oP+LuDZqgsBCf/EZ/o/nTu4XSpP+IXV7rVioLTOm9VkoLEJgWnRaQUZKYauhuodcGV5j850AzirVvmq+4Wt3/stY/Xw31lBaeWVjIeaIj0sKVu7eVKHC5Mn+eK04XCqit9bgUx0jynl8ytemy/+HcEEHhdAYLT6/ry7gi8mYCDU1PNL9sKTocaNqpovo3bEfixr7/irnx4RZ1vOut7va37D/imByc7OMyY5EaVp8FIlSDdhNc3EHZ4es7cIx9zqVTUEF09BqejpZsq+/PGcV6Z3FVxsr87nq8zsPq4eCCAwNsJEJzezppPQuBVBebBSfdOi5WP1cHpNYeMtiE4+QSkStBEgeZ8DUEyDpGqZ1Zbc8uOl4KTP288GSmsqrqlwOrwNJ7M1toGwp/BAwEE3k6A4PR21nwSAq8q8Hhwet1JylsXnDTnq3PVj4HmJUOXBKdXvax5cwQ2TuD/AQAA///0N/ulAAApNElEQVTtndluI0t3pYPzTI01nfP7/S+NRl8ZhmEY6L7sq34AA/Y5NahUGklxJr1WpKKKGiilJJbGL1wSKTIyM/LL9J/rrL1jR+Gf/+XfF4EGAQi8eALVciW0W83Q7bTCZqcdatVKmC+y//cuFgphOB6Hw+PTcHzaD/3BWZhMpqGgz9fVFjrWbB5Cp9UI//TpQ+i2W+va9dr2s3y6o/EoHJ2ciUcv9M76YTyehWIx3JmJuTea9bDRboftDXOvRu5G7+ONx5PI/KTXC8c9H2d6r+OsDQI7ggAEHkSggHB6ED82hsCzIbBKOP16gEsonFoo9MNpv3dvobDqhJ+7cLKIsYC0mJxPZ+F0MAx7B4fhrD8Ik9k0zOfzO4sms8i4NyQU22Gze1WwjiRYj8T8RD+9/lkYTcb3Os4q7nwOAQg8LgGE0+Py5mgQ+G0EVj3ALZzcxpNROOkN4gP8uHcaRnJYSvdwWLK9Xf39HIWTxVI6/8ViHhayxMYSSKPROIqYw6PTMBSX+zafc61SDZ22nb62XKfWFadvJMfp6KQn9nK2JNLG08l9D8d2EIDAMyCAcHoGF4EhQGAdBG4KGXn/k8lED+6hwkWn4fDEwmn6qoXTL4fJ4mmRnf9gEPpnQ/0Moniazu003S9bwfuUBgu1Wlmh0U7YkNvUaTZCpVKJYi0d347TwbHDdL0w0LERTuu429kHBJ6OAMLp6dhzZAislUC5XAqNWj3mFu1ub4T6Uq6NDzSdTsPZ0OG6Xjg4OgrD0esVTslpsss0m80kVmZhOBgpPDeQeDkLfXGYTucPyjVKDltdwmmnuxm6Ek6tRi2Uy+V4XZNwcm7Z/sGxHKd+GIyGOu5srdednUEAAo9LAOH0uLw5GgR+G4GS4m71GDZqhfe7m1FEOZ9H/2JzXs9QYaJjhY2+/1Buj8JVrzFUlwTLVHlLg9EkOky9fj9zmMRgMp9FMWXh85Dk+CScmrVq2NnaDBtKyq/r/WXhZLG0t38UTiWchspvmjmDngYBCLxYAginF3vpGDgELhIoFguhUiyHjh7gH9/vhla99nN2l3s6v2cq0eBE5a97+9F1eS3C6afDJHdp5hDaQiJRoci+cop6SgIfKDS37hBZEk6tWi28f7cdc5xqcv2KpVK8MEnA2d0y71NxnzwgNHjxavMXBCDwVAQQTk9FnuNCYM0E7J4UNZ++owTlPz/shnajcVE4KWylD8KR3Je/v37XFPzhq3CckkCZSjSNVGJhMBiHU5UXcGjOYmmiEKVnzFnorLMl4dRWKYI/379XYngjFKRECwVl3KulcfUUHvz7m4STHKffMY51nhP7ggAEbieAcLqdET0g8GIIWDxZOP3j4zslKjcvCKd0Es61+evrN4mLQQxVZY/59O39X5OQeMw6Ts5hshic6nUsgTSQWDpTArxDcwOFxabO3ta/+9Rnuo2EdhvFmBPC//Hxat2qJJxOlVP1l4SqhdO6xdttY+R7CEBg/QQQTutnyh4h8CQE0oN8Q4Lpj0/vQ7d1tQClhVVPxS//+mzHqfcz/2kdA34s4ZQEifO3ZhOH5OwwDcKZnB2XGRjLdXJI0u6OmRQemMt0ExuPpd1sh3/88U4OX/NaYXQiEff5y144loCKruBNO+Q7CEDg2RNAOD37S8QAIZCPQBIuMXQkx2mj2VLoqHAldOScmy/f7ID0wlR5T6m6eL6jrO6Vjv+7HadYj8kuk0JzQ9VIcmmB096ZZgmOYvL7Yrb4LQ7T5TN3Mc2yQnMdFb789OHd1ZwyuWAey7HChr8jNHp5PPwNAQg8DgGE0+Nw5igQ+O0EknBxUviHdzuxGGNVycqFS8nKnuX1XdPjnaw8kFvj6frraOn46xZOvxymX/WY+sPzekxK/B4PJwrVKY/pXAR6HHZ2fncriWtDJR+cjP9O5R9cCmJ5FuNCXF0GwcusfPv+Y+3J+L/7/Ng/BCBwPQGE0/Vc+BQCL46ABYNTehqaEr+9tRGXAGnWr06Pv7wEiEsUrCPP6XcJJ1+IrB7TPC6NcqY8pp5Dc1q+5Ewu00PrMd3nQjsEWL+wNqArhv9ao877zOpmjWPF8IPDY5VGGD+KE3af82EbCEAgPwGEU35W9ITAsydg8eIlQH4t9nvxgW4jxnlBdppiIUw5TxYf60ieXrdwSk6TQ3IWHWeaBdhTntBQocYsjymr+u3jPobDlC6+j2eB2lQZgm05TV5Q2c5TqVKKOWNp3JcFKmvUJYK8QuBlE0A4vezrx+ghcIVARSEkF2J07s277a7eXwohKffGYuRYC/5+2/+hZPH1zK5bp3CKeUzKD1KKd8xjsmg6tcMkp8kCxMLFbR2CL9tT/t8+tM+1I67vVS9ro9NUrpNCopfKEAxjSPQk5pINJfwmawqJ5h8pPSEAgd9BAOH0O6iyTwg8IQG7L64i3m1lScttLQOynHuTDW0e1637rNwbT923EPDPQ9pDhVNyamZO/PbyMBIbTmB3aG6i92MVj3TV7eWxPqbTtMzGY20r+f5PJYW3W3V99SvYmc6jp3E7Cf+k3/s57uV98B4CEHiZBBBOL/O6MWoI3EjArsiG6gt9cn2hVvNC3/Rg9+y6b/uHUZyMtQCwax79evxf2CTXHw8RTqkek/cx1jjs0PTlMJ1oXb2Yx2SLSf+ewmFaPnlzLQmgF1TutJvXVmiP/SWseprp59l0nlX3EK7Lx+c9BCDw9AQQTk9/DRgBBNZKwOLDOqOlitYfdj27rhkcvkuz63wwiyeLJYfrLE7s7HiJkocIk7sKpyTgUj0mj6c3HMaFiF3Icqw8rOm5yySfSfWYPG4N/Ila4lqtluOMxa5CoV6frlqtyAX7NaiUyB5n07liuGb+PYTrrz3zDgIQeA4EEE7P4SowBgiskUB6wNc8u26zq4d8O7QUrkuLz6ZDLS/6u39wFM7GoyiotGhI6nKn17sKp+Qyef228XgmweSK38pj0quLWs6mj1OPKe9JWrxZIDWrtbC7rUV9u+04s66okg/Lbe4K5qov5eT7H+LKbLplOryHwMsngHB6+deQM4DAFQIWMRZKTSUwd+WK7Gx1rtYZOl+u5ETJ4V+/OUncuU5XdpX7g7sKp6nKIPTlLLmAZV9iaTLMlkiZaYHelMv0lA7TdSduw6vd0CLKH3ZCV2sBBi2sfF1S+MFxPxyf9HReg5iv9dzO47pz4zMIQCAfAYRTPk70gsCLI5BVti6HlkJ1n1QQs6UHvcVNailUluU6HYRTPejHM+c6yelJne7wmoTTz8rlWvKlGGebZTvxoeeaWTaTYHMC+NCL8Spxuq8SAx7DU9Rjynt6zm0qSyRVS8ptktP0YXf7SqVw78sCqS8h+sUFL5XjNJ2pZMIS87zHox8EIPB8CSCcnu+1YWQQWAsBL0L74b2XYLnokHjnFk8Tre3mENmRf45P43pv98nJScKpqRDh7s5W2JTAaNQqmqpfjudhETEYTWI9JjtMw5jHNAkO1XldOW//HJ0Zj8s5Yw59bm50wqaS7V0nq1IpX3DoUujxWA7atz0taaNXGgQg8PoIIJxe3zXljCAQCaQHvgs17u5shi0VaqwpkXk5SdwdF5ri70VxTyScvu0fxMVy7bC43cV5SserVkuho1II3XYrtDRVv6qQodtYyeencmN6/azq91PXY4qDuuXXMoemHDs7TZ6lWC462f4iHS+xMlJu06Fym/Z/KGdsTYVFbxkiX0MAAo9MAOH0yMA5HAQek4DFjIVLs9mMM8C25JjULy0N4vHIUwkDhcviGnZaW81Vr+8TOvPxCgppuSBkrVyTS1MJJSVPL2TZuOjmRMJipPXbZnKf3Nc/bs/ZaSqXi3E5lY6EYFyTTmsBFpYkZQp5OqH9UI7dsdYAPFP4cawk8ed4XhE4vyAAgXsTQDjdGx0bQuBlEChayBRTrtN2aNYVsltq6cFvt8RT6F2e4FjlCUYK4fnBf9FXWdpwxVuLIYe2HO7zQrhFuTMLJXzPXdjSX5x/99xFhd0mn0tNITnPTOzKsduQeLJrd7WgaNBsQOc2HWS5TTH8+CufbAUqPoYABF4gAYTTC7xoDBkC9yHQVqhpd0ehpnY9VCSklkN2Fk/OM7IrdKKkZoeaPCNs2RW6yzHjdtqpi0WmFgXVM6jHlMZz26uFnX9aEpoOdXaVZG8nrShFeG6UxV04ROc8rZPeUNwO4hI2t+2b7yEAgZdLAOH0cq8dI4dALgIWLEpjiuvXbW2orpNmu7VatVBR9evlZo3jmXgDrbG29+M4nKo45nAyUlhtttztzby3W1av1EJHa9G939m4Us4hgZi4rEJ/FI61dM3h8Umseu70p+fuqKXx8woBCNyNAMLpbrzoDYEXScDiyevX1cvV0FLIybk6zbrXWLvYLJ5mykFy0cYThe2OJASc5Ozt31pzocvNrY0YnmtoRl3M1boGgwt2OjesrxDncKrCnVKpiKa3drdwvm+JAMLpLV1tzhUCIuCQ3TvNDnO+jsVUKuC4DMdT6wcSTHtay66nafV2VSwI3kJbzgn7qNBmU1XXVzEyk1Mlgn/bcwFRyg+8hfuDc4QAwol7AAJvjIAXqHUdIlcU39RPpVK91lGaalaYF9s9UQjqWLPF3orz5PDc1mZHi/i25MpdXarGt4sdpYnW1jvVAr7HJ/0Y1hzJbaJBAAKvnwDC6fVfY84QAhcIXHRUtlSqoH5hev1yZztPFkzf34Dz5KRv12eyqHS9plVOk/ksl2/oq/zAyI6cZwzSIACBV08A4fTqLzEnCIFrCCiXqSlnZXMrWwTY1b6Lqvd0XS6TnaczOU89OU8nWpbFQsoJ45YJdl7uWq7gmtE8yUcev8/X43ciuAuFdpT/1ZFwatarWuvvYvK8B+nz9SK+5vEzB0yLI0du1+Q/eRsaBCDwugggnF7X9eRsIHArAT/kna5UrchdaagwZtc/3VgYc9XGWc7TOOwfaradC2ROVCDzPOfpJQsnn29ZeV41hSsdmttVMrgTwa/LaUpsXOjy+OREP2fKa1Khy8ksMIsu0eEVAq+fAMLp9V9jzhACVwhYPNk9iU6L6hRtK6enrTIF9Wr5vGDlVfvETstQP/3BUDk9ro49VIhKAkohqpfkPCWnqazQXE2zDB2q7CjXq9Woa9ahzv98iZhlaNFp0rI0Qy0bY+ft4Eg5X6pzZectsVzuz3sIQOD1EkA4vd5ry5lB4EYCyXmqeW25difOstvoNORE1a7dTjor1nn6VWH8TCLKjstY4iELe1274TP70CJISV3RZWrJceuqTtNNFcHT8MeqaXV8OojV1U97Wgx5jNOU2PAKgbdEAOH0lq425wqBSwQsnpwUXSmVQ0OOy2bXzlNzpfOUnBeXJ7D7MtT6dv2zURioZEFWw+j55T4lh8khRSfG22VqtRqh1WyEumbN2WVzMdBsaZiLTls638xpOgtHJ6dhIMdtorX2XGk9irBLTPkTAhB43QQQTq/7+nJ2ELiVwHXOU0fLi9QkKK5L/U7O00xrz3lKvoXTkYo/Zu7TJAoKH9T7fQ4tiRuLporCcA3VsdrWYseuZ1WpaBFifX7d2nPZ2Ody1LSGH07Tc7iUjAECz4IAwulZXAYGAYGnJbDsPNU8u6zdiM5TW9XFS9fMtrMY8TbZOm1zCSi5T0qaHsiB8s9oOA7jmYtmPr4DtewwOYerWqqEmmbJNewuKfG75h8lxqf1+tK5LF8Bf5Zmz7kAqBc9Hg5GOE3LkHgPgTdKAOH0Ri88pw2BywSS81QpF7WwbZYwvSVnxrPMnBS0aqZZcqC8QLCXaulrsVsXhnTlcYf0HNKKSUWqfrScC+VPr2urZund1t9ix2NJx4ohSIXgGhaCTSV/a3Fjn4sX6l3tMGU1mjzQ4XgSTuSkMXvuuqvEZxB4uwQQTm/32nPmELhCwOLJAiSua6cp+k3lO7WVC9Rp1VcmjXsn0aFZzLTO3TwuzTLR7LuRpumPVeNorPdjiZCpQl6xUKRdKIX5Vq3gUpBy8v6SgEoOkmpxXttcCsBhOLtLNQmlssJv1ap+5JRVtd5cdJf03udUkigsFko3hhEdfjzpq9SAnKaYu+XSC1q/L7G5dhB8CAEIvBkCCKc3c6k5UQjkI5Ccp2KpoOn5FYmnRtjd6CqZuhZKEh0FCZBV7pOPYNenqF8pB2og0TTUQriD0VCvk+hC2Z2yePL/Zf+yV2sjCyYLocw50os6uG/6zjPi5C3Fr/3qvnaRnOBdr9thUlkBOWYNiafbc5i8f+djzcPCYk6vfYXkDg6PVHbACe9yzGZaIPlczGW9+Q0BCLxlAgint3z1OXcIrCCQ3BWHu6qacVdVjlBTYsQFM+sN5witrvfkXdox8j6cAzWVGLGImqkOUnSk9DqVM+UQngWUC2lOz2epLSRSkpi6MLRzsVSQmItLo2hMLlxpwRT/lpNU0nIpdpTiq8WUrKuCvk9jubC/8z+SUzaROzZQXlZPTlNfIm+sPK1xGtO5C3fd9nwGAQi8PQIIp7d3zTljCNyLgKtrd1WuoKvE8VajFmeoJVcojwNViC6S3J0oouQgWTTNp0os98w1C6iphJZEloSWc5CkvLJxOmynn1IUQhZLEnJO7q54bTkJOIkjz4xb3v9NOUzp5O0yuTkPayAn7LSncgNazHioek00CEAAAqsIIJxWkeFzCEDgAoGf7lO1KtepJgdKP3qtOq9IOUS3OTu/diZPKeqiLDxmkWP3SWZTKOh17iidmrRSbEk/Fb2NHDCZTtFlspiyWLJoy/qeb6Ct7HZd19IY7YQ5DNdX9fMzuUtDJbWPNSvQpQeyZPbrtuYzCEAAAvrfpn/+l3+//n9hoAMBCEBgicDl3CcXzMyWKlEhSdV8cugsjwO1tMtr31oEJVHkDnao8jhI1+7s/MPkLmlvSl5fxIR1i6ajUxW01Cu5TDfR4zsIQGCZAMJpmQbvIQCBGwks5z6VlVNUVq5TVbPYYn0kOVGe7u8ZbRWF0vy9m3TPSgdo1cHsDC23VQ7Scp/l997+PDKocOBM4UDP8FNITs7SSM6Sa05N9bc/nyhcaJcpndvyfngPAQhA4DIBhNNlIvwNAQjkInDZgaqrXpIXCm5p0dxG3cuYlJfibdkub8qFynXQWzr9dJaS7lLIzqURBkMtTixnyQv0DlVfCofpFpB8DQEIrCSAcFqJhi8gAIHbCCSXJs5sk8NUKWuW23nytp2oWE9Jr1m5AH3vWW7nM92SI3T5GNc5VMsO0qr+sYq5cpcmqrnk2XrOV7LLFF/lLM2VfB6/kwOFw3SZIn9DAAJ5CSCc8pKiHwQgcCOB5EC5k9OdKgrjZTWVvJCuSxgojFezE6VZcK7E5Czvn/WYvJVzpNwUNnOm+FLL+i597+9iF5c8UN6S/rAoGo9ceDMLxXkBYteO8nIwqdgm9ZiWoPIWAhC4FwGE072wsREEIHAdAYsnt+gQyVJyuYCyZsIVpVgcpiu6cnecGaccJDlPqRaTq36XlJdU0HducS+pUrg++hl5i7PvnOCduUquAeWyBjMd1y7SXPWhHK6buzaU/na5g1hoc2lc8QD8ggAEIHBPAgine4JjMwhAIB+B5EQtiyo7PxZLXmjXieQluVMWWLEy+bmxtKSb4oFcdmmmZV0siGZykVJit0WUHaXL+7+cYJ5vtPSCAAQgcDMBhNPNfPgWAhBYAwGLmmUhZFGT5S2psKVyo/w+Ok7yllw53HlO576TXrMZctoifmd3KRNjylU6f3/d/tcwbHYBAQhA4AoBhNMVJHwAAQg8JYFMFOEgPeU14NgQgMBqAgin1Wz4BgIQeCICOEhPBJ7DQgACtxJAON2KiA4QgAAEIAABCEAgI4Bw4k6AAAQgAAEIQAACOQkgnHKCohsEIAABCEAAAhBAOHEPQAACEIAABCAAgZwEEE45QdENAhCAAAQgAAEIIJy4ByAAAQhAAAIQgEBOAginnKDoBgEIQAACEIAABBBO3AMQgAAEIAABCEAgJwGEU05QdIMABCAAAQhAAAIIJ+4BCEAAAhCAAAQgkJMAwiknKLpBAAIQgAAEIAABhBP3AAQgAAEIQAACEMhJAOGUExTdIAABCEAAAhCAAMKJewACEIAABCAAAQjkJIBwygmKbhCAAAQgAAEIQADhxD0AAQhAAAIQgAAEchJAOOUERTcIQAACEIAABCCAcOIegAAEIAABCEAAAjkJIJxygqIbBCAAAQhAAAIQQDhxD0AAAhCAAAQgAIGcBBBOOUHRDQIQgAAEIAABCCCcuAcgAAEIQAACEIBATgIIp5yg6AYBCEAAAhCAAAQQTtwDEIAABCAAAQhAICcBhFNOUHSDAAQgAAEIQAACCCfuAQhAAAIQgAAEIJCTAMIpJyi6QQACEIAABCAAAYQT9wAEIAABCEAAAhDISQDhlBMU3SAAAQhAAAIQgADCiXsAAhCAAAQgAAEI5CSAcMoJim4QgAAEIAABCEAA4cQ9AAEIQAACEIAABHISQDjlBEU3CEAAAhCAAAQggHDiHoAABCAAAQhAAAI5CSCccoKiGwQgAAEIQAACEEA4cQ9AAAIQgAAEIACBnAQQTjlB0Q0CEIAABCAAAQggnLgHIAABCEAAAhCAQE4CCKecoOgGAQhAAAIQgAAEEE7cAxCAAAQgAAEIQCAnAYRTTlB0gwAEIAABCEAAAggn7gEIQAACEIAABCCQkwDCKScoukEAAhCAAAQgAAGEE/cABCAAAQhAAAIQyEkA4ZQTFN0gAAEIQAACEIAAwol7AAIQgAAEIAABCOQkgHDKCYpuEIAABCAAAQhAAOHEPQABCEAAAhCAAARyEkA45QRFNwhAAAIQgAAEIIBw4h6AAAQgAAEIQAACOQkgnHKCohsEIAABCEAAAhBAOHEPQAACEIAABCAAgZwEEE45QdENAhCAAAQgAAEIIJy4ByAAAQhAAAIQgEBOAginnKDoBgEIQAACEIAABBBO3AMQgAAEIAABCEAgJwGEU05QdIMABCAAAQhAAAIIJ+4BCEAAAhCAAAQgkJMAwiknKLpBAAIQgAAEIAABhBP3AAQgAAEIQAACEMhJAOGUExTdIAABCEAAAhCAAMKJewACEIAABCAAAQjkJIBwygmKbhCAAAQgAAEIQADhxD0AAQhAAAIQgAAEchJAOOUERTcIQAACEIAABCCAcOIegAAEIAABCEAAAjkJIJxygqIbBCAAAQhAAAIQQDhxD0AAAhCAAAQgAIGcBBBOOUHRDQIQgAAEIAABCCCcuAcgAAEIQAACEIBATgIIp5yg6AYBCEAAAhCAAAQQTtwDEIAABCAAAQhAICcBhFNOUHSDAAQgAAEIQAACCCfuAQhAAAIQgAAEIJCTAMIpJyi6QQACEIAABCAAAYQT9wAEIAABCEAAAhDISQDhlBMU3SAAAQhAAAIQgEDhf/3rfyzAAAEIQAACEIAABCBwO4HC//63/4Nwup0TPSAAAQhAAAIQgEAo/N//9/8RTtwIEIAABCAAAQhAIAeBwn/+198Ipxyg6AIBCEAAAhCAAAQKn7/uIZy4DyAAAQhAAAIQgEAOAoX//vwN4ZQDFF0gAAEIQAACEIAAwol7AAIQgAAEIAABCOQkgHDKCYpuEIAABCAAAQhAIJdwWjiYN5+HUAyhUCjqJ4T42SPw87F01AceafFo433gQNkcAhCAAAQgAIFnTCCncJqH2Wxu3RRKlXIoSs3MpZx+t3iyaPKx1iGcHmO8z/g6MzQIQAACEIAABNZA4FbhZN0ymUzC6dkgLGaLUG9UQ7VcDqVySaKm+NvE02KRibXJbKpj2PIqRKfrLuecCbuFtiuESkljLtkts/yjQQACEIAABCAAgbsTuFE4JcfndDAIn7/uh8l4HDrtVvbTqodKufJbnKckmoajcTg+7YWxhFuhJOEUPa/8J7kI8yj2qpVK2Oi0Q71WRTzlx0dPCEAAAhCAAAQuEcglnE56Z+G//v4S+qNhaNXqodlqhnazERqNWqguOTkWWusI3y0UFpzOZ6HXH4bvR4dhNBiHUlHCST93aYv5Isz0U5NL9m5zK7Ql9srFkkQYrtNdONIXAhCAAAQgsE4CNkims5k0wzyaIo4MLUeF/LmcmTCTqMiiTkoVco61TZQbIkc/96tt3awbyiU995e2cZ9MZ+gYauWi95s/InUn4XTcH4SiBl1VmK5eqUYBtdnphHZdTs4ac58WgjnRz7EE2/fvP0JvPBIww7qjcBJwQ29Xa+Hdu52w0W4qZGfhVIqw+AUBCEAAAhCAwOMTmE6n4UxRpZnScYqFUkynqVeVQy194WZhM5GBYnE1nkydrBOq1Yr6FS8IrMsjT/udTGbxq0qlFJqKNpWVYuRm0eSc7an2ORiN4meNWi2UpWGWhVv8YsWvfMLp7Cz8919fw5GEjJsNm5LER6NaD612I7Qa9dCoy32KuU/FB+c+WTiN9HNy2g/fJJz6QwknHfNewkmCsqWxfZBw6nZaofaGhFO6QazWHbakQQACEIDA4xJwikl0U/wf/37+rCky87hnsZ6j+dzn01kYTifBqTjDoYWTnk363NGrZrMucVQKZQmpsWby92TWOFXHzbZJUc5QVeLKES+nCqUW96v+E+13MJIgU072WMdxq0iINaVRatVqqOn9zPtV+pGPPXe1ADXvty4DqN3QfpXac1vLJZxOLZz+3gsn/V7cn2+C5Z+GBtR27pNCeJ015D4hnG67bPm+jzfoeCr3birHUzfR3LceDQIQgAAEHouAozQVuRl+gPth77STtzjL2+LGs+SHSvnZPzwN/cFQHLI85LmcpZKEU0vCqSmjww7QUM+uvR8HEkATiZpazHAeDkahovd/yAhpSTy5pf2OxhNFqfrhTCk+drLmMl/cinJdynKd3H9Tuc52mr7s/wgTCaeq9uU2ljlTkXD6tOv91rXPm9N58gunz3vhtN+PB0m/7GRYsJXLRbk6cp00MCvBpnKfHjKLDeGUCN/91TeRb8KRbEor+jPdnFPdgA5Z6pu775AtIAABCEDg3gQKDkPpwV1TmMkP5ZrEk/Nubns43/uAz3TDJHDs9nz5th+Gyl2uOs1HLJya4+Yc5MhJDpFDbT+OjiSA5qG70Y5i8+DoOFSL5fDHHx9iJGmgZ5yVU7NWifv4cXgcBhJE/izZBBapc5kHdpy2tzbj8/HL3o8wkyO1sdGJxz06OonC9n1M6WndGrJ7kHDyEf0otjYzFIfv6grf2W5z7lPTUKT27nqDIJxM9u4t3ZhDzX48POmFE6nv4dkwjHXT0CAAAQhA4GkIOELjyMxGtxMjM57hnXJunmZEj3/U9HxKESxHQt5tb4Wa8qVd8mh0Hr6TjlLqTz0O0CLLeck725sxF+rz5+8xcPLp/W7UG98PDpW0FMLu9kbsvy/hFIWWImAOvblZSB0f96RDFlE4FRaFcHB8EpPMP+5ua/NF+GohJcNhZ3MzdJradinXKu7k0q8HCyfvLzlPChPGk0m5T51GU3Wfaud5RfkVNsLp0lXK+We6MZ0T9nVvP+aI2eacqv4WDQIQgAAEno5ATQ/jTqsVS+NsKt/Wic4xEPB0Q3rUI6fnU5ql79ymjx92NbmsLtE0U3RkpHqR/eDZ8HbmHNYbyASoi9M7CaPJZB5n98ftJJyczH0kAWTrZmuzE52kve8SUrJzdiTInNfk1pd5sK+Qn/e7tbWhiWalcKQyRw6ffvqwE5PF/1a5panEW7fTDd1WI4qum4TtWoSTB/fLecryn4qSjY1aI2xvdlUGoBmTsopSjnkawikPpat90o0ZFb1Cq8cxtKoCoOimq7D4BAIQgMAjEsgmVFVDR3k273c29Hysv6lcp/R8Wi2cBoqSaAKa1GRL4mWVcJpKcH14vxPTgnz5nNjtSV89zZD7/FWOlIyC3Z3NKL78/RXhpL7HPQknvX6UALN4/fvb9zBT7pMnkHWaMnzkVj2KcPIAU7NoKisO2ZBq3Ol2VbagcafZbAinRPJur+nGTMLJOWmp/sXd9kRvCEAAAhBYJwHXEnLSs4XTu+0uwumK43RRODm86XIBdpzeSwglx8nC6aOE00ZH5YWUL1ZUXpRFlp97f8kwcHkDO06e7e9cMgunHwrp+Vm4ubGpqFghc5yUrO+Q3xXhJKPntlDq2hyn5RusVlYsVzdHS3HGVjML1enMcuc6IZyWaeZ/n4STQ3VfpKCtqseqlaHQLQ0CEIAABJ6QgEN1G+22XI12VlMwx7T3Jxzu2g+dnk+rHCfPmDtZCtUpczqcDYcxpPlBuUhO5nYh7hSq2+y25ApV4uQ0D/a0L+Ekx8nO0dbmRiaczsVXJpxC/Nx9j45PVXuyFP5UqNDtb23n2XbeLhb3llgrntd9ih0u/XqwcLKKszIsyS4razqhlzdxXlNXxSad4HWfukkIp0tXKeef6cZMyeE92Z5W7JNYz0LVWQnZ5SRJNwhAAALrIaBcZGXhqE6Q3KZNzeLyChZ1OyU3PJjXc+TntZf0fHLCtwXOVOUD7L65fpNn1VkYecUQr4PblHZwjSULHFcK397oxrDm3v5BLIZtp8jlBZxgbv1R0z5cG2rv4DiMlRdVU9HrbGa/Zuy50KZcp6Jm/28pOX+uXCcLKWeV25lyy/4uxL870i636ZYHCaeUFF4qF2SnVaXwGlFNN11ESrPpXO37Lk5TPAP9QjglEvd7deFLiyWXI+jHQmB2naSa9DkNAhCAAAQej0C25Ec55s3EfF8lJd91pvnjjfb3HSkJp4HqOH2XwHFxy8V0EcXSVM8mF6dsa0ZbU8KyJZE5mIzDV5ct0KvzpaUmwsjJ4jJm/nz/Lq5isvfD5QqU9K3kcC+b0pNDNVQJnqGiLtOpnneasObPyzJ0HLrb6LZjFfIvX/di4nlTx3E7k8HgWY+fPr4PGxJkt+mWBwknxxWjyyQLsiGx1NIJd3XQaiUbTBzRPX4hnO4B7ZpN5lLaA6l618OYqQBmwcFcGgQgAAEIPBoB13Eqye1wRWpPc3eu01sugOnq3qcqUtnTf9Q7FOfQmk2YioSLC1S2JXCqEpfJQRophJetI5fVZnKdyN0tO1AFFcg8lHCahS05UlVtP/MzT4bBqUrxTLRfN9fQ8iy9Rl01JlXw0ukr3w+OJLCy/bqPl3exIHunsgd2u25rDxJOzmWy1dZW8ndTuUx12WV3WShv1eAQTqvI3O3zbCFDL7biShV2nO62Pb0hAAEIQOCBBGSV+JEf11uVaKL9iiqNJHIconM4s6LQpRPBPdvNjs9CTpLF01Tfz/TexbxdF9L9HEqz2HKFcDcXzbSzZIfJyeOjkbfLhFM0d2oqQqoJa3G/CtW5/IFDeHO7UmoO48X9yvXKM/s/v3DSkiuuseCpfx6AVVxdCm7jPAHcNRHWpaSvE06Gpn93akbi6NRbXavuTrDoDAEIQAACEPjNBFLIbiYBY3Hj5cC8nl8mLC8WzPZ//KtDcCjPzRojhTkzYyD73IaNtYmjYHbzZoqyzGORJOsG7Vt6JX2XAi/e3gsIX95v/OCWX7mE08n5Ir+94UBJbdXQkMNkS82WmU+kLFXjxQvX1S4Lp55ilo5vitjdDiFCNlls/b3FRX7vBoveEIAABCAAgccjkAkjHe/cFUmiaHkEsU/6wFojvddr+u7ydunz1PXy9/48BmDOBZntrOX9pu1WveYSTs6C/6yS5BPZYnWF5NqqCN5tPzyXadWgHG90dr2P++PwREnOo1Vdc33u2Qw7iol65WOvhWN1SoMABCAAAQhAAAJ3JXCjcPLObPKMVYr8pDeUupvFMuZVxRjvswZd3sFlKlRxSNloXgjQUw4f0jwtsd6oxrioY5zXqc+H7J9tIQABCEAAAhB4GwRuFU7G4NDZ+DyBq7bGXKabECfxNFUth1kKSt60wQ3fOXaaJY4hmm7AxFcQgAAEIAABCNxCIJ9wOk/Q8r6cy2QX6oFa5pZhZV//jFMqOexBTS6TG07TgyiyMQQgAAEIQODNE8glnN48JQBAAAIQgAAEIAABEUA4cRtAAAIQgAAEIACBnAQQTjlB0Q0CEIAABCAAAQggnLgHIAABCEAAAhCAQE4ChW/7B4ux1jOjQQACEIAABCAAAQjcTOB/AGfN5PB24ebIAAAAAElFTkSuQmCC"
          />
        </defs>
      </svg>
    </div>
  </div>
  <div class="flex justify-start items-start gap-[42px]">
    <div
      class="flex flex-col justify-start items-end flex-grow-0 group flex-shrink-0 relative h-[578px] overflow-hidden"
    >
      <img
        src={image_19}
        alt="..."
        class="w-[402px] object-contain group-hover:blur-3xl"
      />
      <div class="absolute bottom-2 right-3">
        <Badge lable="#1 Upload" />
      </div>
      <CardOverlay
        title="Upload"
        subtitle="Step 1"
        instruction="Upload your product or company image featuring a person."
        perks={[
          "Lighting - the models generated will match the lighting in the",
          "Pose - the person in your image can be in any body position",
        ]}
      />
    </div>
    <div
      class="flex flex-col justify-start items-end flex-grow-0 group flex-shrink-0 relative h-[578px] overflow-hidden"
    >
      <div
        class="flex flex-col justify-start items-center group-hover:blur-3xl h-full"
      >
        <div
          class="flex justify-start items-end flex-grow relative gap-3 h-[96px] "
        >
          <img
            src={image_23}
            alt="..."
            class="w-[96px] h-[193px] object-cover"
          /><img
            src={image_21}
            alt="..."
            class="w-[193px] h-[193px] object-cover"
          /><img
            src={image_22}
            alt="..."
            class="w-[96px] h-[193px] object-cover"
          />
        </div>
        <div class="flex justify-start items-start relative gap-3">
          <img
            src={image_24}
            alt="..."
            class="w-[96px] h-[193px] object-cover"
          /><img
            src={image_25}
            alt="..."
            class="w-[193px] h-[193px] object-cover"
          /><img
            src={image_26}
            alt="..."
            class="w-[96px] h-[193px] object-cover"
          />
        </div>
        <div
          class="flex justify-start items-end flex-grow relative gap-3 h-[96px] overflow-hidden"
        >
          <img
            src={image_27}
            alt="..."
            class="w-[96px] h-[193px] object-cover"
          /><img
            src={image_28}
            alt="..."
            class="w-[193px] h-[193px] object-cover"
          /><img
            src={image_29}
            alt="..."
            class="w-[96px] h-[193px] object-cover"
          />
        </div>
      </div>

      <div class="absolute bottom-2 right-3">
        <Badge lable="#2 Select" />
      </div>

      <CardOverlay
        title="Select"
        subtitle="Step 2"
        instruction="Select the model that best matches your image."
        perks={[
          "Diversity - choose from 50 different female models",
          "Consistency - the same model can be used across poses and images",
          "Coming soon... we will allow users to design their own models",
        ]}
      />
    </div>
    <div
      class="flex flex-col justify-start items-end flex-grow-0 group flex-shrink-0 relative h-[578px] overflow-hidden"
    >
      <img
        src={image_19}
        alt="..."
        class="w-[402px] h-[578px] object-cover group-hover:blur-3xl"
      />

      <div class="absolute bottom-2 right-3">
        <Badge lable="#3 Generate" />
      </div>

      <CardOverlay
        title="Generate"
        subtitle="Step 3"
        instruction="Generate your model image."
        perks={[
          "Resolution - we match the resolution of the uploaded image",
          "Body - only the head and hair is generated, no other body parts",
        ]}
      />
    </div>
  </div>
  <div class="flex justify-start items-start self-stretch gap-[46px]">
    <div
      class="flex flex-col justify-start items-start flex-grow relative group overflow-hidden"
    >
      <img
        src={image_30}
        alt="..."
        class="self-stretch h-[408px] object-cover group-hover:blur-2xl"
      />
      <span
        class=" absolute top-6 left-6 text-[22px] font-semibold text-left text-white  group-hover:blur-3xl"
      >
        MODELME
      </span>

      <CardOverlay
        size="wide"
        title="MODELME"
        subtitle="MODELME vs Traditional Photoshoot"
        instruction=""
        perks={[]}
      >
        <div class="text-lg text-left text-white">
          <div class="flex gap-2">
            <span class="text-lg font-bold text-left text-white">Endless</span>
            <span class="text-lg text-left text-white">
              model diversity at your
            </span>
            <span class="text-lg font-bold text-left text-white"
              >fingertips</span
            >
          </div>
          <div class="flex gap-2">
            <span class="text-lg font-bold text-left text-white">Intuitive</span
            >
            <span class="text-lg text-left text-white"> software for </span>
            <span class="text-lg font-bold text-left text-white">beginners</span
            >
          </div>
          <div class="flex gap-2">
            <span class="text-lg font-bold text-left text-white">Change</span>
            <span class="text-lg text-left text-white">
              model, hair, makeup, expression, with a
            </span>
            <span class="text-lg font-bold text-left text-white">click</span>
            <span class="text-lg text-left text-white" />
          </div>
          <div class="flex gap-2">
            <span class="text-lg font-bold text-left text-white"
              >Stress-free</span
            >
            <span class="text-lg text-left text-white">
              image generation in
            </span>
            <span class="text-lg font-bold text-left text-white">seconds</span>
          </div>
          <div class="flex gap-2">
            <span class="text-lg font-bold text-left text-white"
              >Royalty free</span
            >
            <span class="text-lg text-left text-white">
              digital models that cost
            </span>
            <span class="text-lg font-bold text-left text-white">cents</span>
          </div>
        </div>
      </CardOverlay>
    </div>
    <div
      class="flex flex-col justify-start items-start flex-grow relative group overflow-hidden"
    >
      <img
        src={image_31}
        alt="..."
        class="self-stretch h-[408px] object-cover group-hover:blur-2xl"
      />
      <span
        class="text-[22px] font-semibold absolute top-6 left-6 text-left text-white  group-hover:blur-3xl"
      >
        Traditional Photoshoot
      </span>

      <CardOverlay
        size="wide"
        title="Traditional Photoshoot"
        subtitle="MODELME vs Traditional Photoshoot"
        instruction=""
        perks={[]}
      >
        <div class="text-lg text-left text-white">
          <div class="flex gap-2">
            <span class="text-lg font-bold text-left text-white">Limited</span>
            <span class="text-lg text-left text-white">
              by model availability and their location</span
            >
          </div>

          <div class="flex gap-2">
            <span class="text-lg font-bold text-left text-white">Hundreds</span>
            <span class="text-lg text-left text-white">
              of dollars in models, hair and makeup costs</span
            >
          </div>
          <div class="flex gap-2">
            <span class="text-lg font-bold text-left text-white"
              >High effort</span
            >
            <span class="text-lg text-left text-white">
              in coordinating models, hair and makeup</span
            >
          </div>
          <div class="flex gap-2">
            <span class="text-lg font-bold text-left text-white">Days</span>
            <span class="text-lg text-left text-white">
              of shooting and planning</span
            >
          </div>
          <div class="flex gap-2">
            <span class="text-lg font-bold text-left text-white"
              >Costly re-shoot</span
            >
            <span class="text-lg text-left text-white">
              required for substantial changes to the model</span
            >
          </div>
        </div>
      </CardOverlay>
    </div>
  </div>
  <div class="flex justify-start items-center  gap-3 relative">
    <span class=" text-lg text-left text-[#757575]">
      Questions about your specific use-case or the generation process? We would
      love to help.
    </span>
    <button
      class="flex justify-start items-center relative gap-3 px-8 py-4 bg-white border border-[#1f206c]"
    >
      <span class="text-lg font-medium text-left text-[#1f206c]"
        >Contact us</span
      >
      <svg
        width="24"
        height="25"
        viewBox="0 0 24 25"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        class="w-6 h-6 relative"
        preserveAspectRatio="none"
      >
        <path
          d="M14.4297 6.57935L20.4997 12.6493L14.4297 18.7193"
          stroke="#1F206C"
          stroke-width="1.5"
          stroke-miterlimit="10"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
        <path
          d="M3.5 12.6494H20.33"
          stroke="#1F206C"
          stroke-width="1.5"
          stroke-miterlimit="10"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </svg>
    </button>
  </div>
</div>
