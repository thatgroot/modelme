<script lang="ts">
  import grid from "../../../assets/icons/grid.svg";
</script>

<div id="contact" class="w-full">
  <div
    class="flex items-center justify-center gap-6  bg-[#1f206c] relative   overflow-hidden py-20"
  >
    <!--  -->
    <img
      src={grid}
      alt="grid background"
      class="absolute left-0 right-0 top-0 bottom-0"
    />

    <div class="flex justify-between items-start w-max gap-12 px-12">
      <div class="flex flex-col justify-start items-start  relative gap-6">
        <span class=" text-lg font-semibold text-left text-white">
          DISCORD COMMUNITY
        </span>
        <div class="flex flex-col justify-start items-start  gap-10">
          <div class="flex flex-col justify-start items-start  relative gap-px">
            <p class=" text-[58px] text-left text-white">
              MAKING THE IMPOSSIBLE, POSSIBLE!
            </p>

            <span class="opacity-50 text-lg text-left text-white">
              Design your unique models that will age and grow with your
              company.Don’t be left behind, join a community adopting
              technologies of the future.
            </span>
          </div>
          <button
            class="flex justify-start items-center  relative gap-3 px-8 py-4 bg-white"
          >
            <span class=" text-lg font-medium text-left text-[#1f206c]">
              Join now
            </span>
            <svg
              width="24"
              height="25"
              viewBox="0 0 24 25"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              class=" w-6 h-6 relative"
              preserveAspectRatio="none"
            >
              <path
                d="M14.4297 6.57941L20.4997 12.6494L14.4297 18.7194"
                stroke="#1F206C"
                stroke-width="1.5"
                stroke-miterlimit="10"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M3.5 12.6494H20.33"
                stroke="#1F206C"
                stroke-width="1.5"
                stroke-miterlimit="10"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          </button>
        </div>
      </div>
      <div class="flex flex-col justify-start items-start  relative gap-6">
        <span class=" text-lg font-semibold text-left text-white">PARTNERSHIPS</span>
        <div class="flex flex-col justify-start items-start  gap-[42px]">
          <div class="flex flex-col justify-start items-start  relative gap-px">
            <p class=" text-[58px] text-left text-white">GROW TOGETHER</p>
              <span class="opacity-50 text-lg text-left text-white">
                Are you a fashion model that wants to work and earn with
                technology? Are you a company or individual that sees
                opportunities for collaboration?
              </span>
          </div>
          <button
            class="flex justify-start items-center  relative gap-3 px-8 py-4 bg-white"
          >
            <span class=" text-lg font-medium text-left text-[#1f206c]">
              Contact us
            </span>
            <svg
              width="24"
              height="25"
              viewBox="0 0 24 25"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              class=" w-6 h-6 relative"
              preserveAspectRatio="none"
            >
              <path
                d="M14.4297 6.57941L20.4997 12.6494L14.4297 18.7194"
                stroke="#1F206C"
                stroke-width="1.5"
                stroke-miterlimit="10"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <path
                d="M3.5 12.6494H20.33"
                stroke="#1F206C"
                stroke-width="1.5"
                stroke-miterlimit="10"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
            </svg>
          </button>
        </div>
      </div>
    </div>
  </div>
</div>
